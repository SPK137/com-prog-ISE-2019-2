import java.util.Scanner;
public class ScoreSort{
	// Do not change main().
	public static void main(String [] args){
		StudentScore [] scores = readScoreFile();	//Read score data from "score.csv" and store the data in an array of StudentScore
		sortByTotal(scores);
		listTop(scores, 20);
	}

	// List neccessary methods here.
	// Do not change method headers.
	public static StudentScore [] readScoreFile(){

	}

	public static void sortByTotal(StudentScore [] data){

	}

	public static void listTop(StudentScore[] sortedScores, int n){

	}

}